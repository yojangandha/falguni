package com.c4.min.microservices.testspots;
import com.c4.mint.microservices.services.spots.SpotsServer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static com.c4.min.microservices.JsonUtility.SpotToJSONString.getSpotAsString;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
/**
* @author
*/
@ContextConfiguration(classes = {SpotsServer.class})
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class SpotControllerTest {
    protected MockMvc mockMvc;
    @Autowired
    private WebApplicationContext webApplicationContext;
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }
    @Test
    public void testGetAllSpots() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/spots").accept(MediaType.APPLICATION_JSON))
                .andDo(print()).andExpect(status().isOk());
    }
    
    @Test
    public void testSave() throws Exception {
    	String data = getSpotAsString(5L);
        mockMvc.perform(MockMvcRequestBuilders.post("/spots").contentType(MediaType.APPLICATION_JSON).
        		accept(MediaType.APPLICATION_JSON).content(data))
                .andDo(print()).andExpect(status().isOk());
    }
    
    @Test
    public void testDelete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/spots/2").accept(MediaType.APPLICATION_JSON))
                .andDo(print()).andExpect(status().isOk());
    }
    
    @Test
    public void testGetSpots() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/spots/1").accept(MediaType.APPLICATION_JSON))
                .andDo(print()).andExpect(status().isOk());
    }
    
    @Test
    public void testUpdate() throws Exception {
    	String data = getSpotAsString(3L);
        mockMvc.perform(MockMvcRequestBuilders.put("/spots/3").contentType(MediaType.APPLICATION_JSON).
        		accept(MediaType.APPLICATION_JSON).content(data))
                .andDo(print()).andExpect(status().isOk());
    }
}
