package neta.ki.daadi.ki.poonchh;

public class tirkonibabba {
	public static void main(String[] args) {
		System.out.println("Tirkonni Babba Gadha hai");
	}

}
