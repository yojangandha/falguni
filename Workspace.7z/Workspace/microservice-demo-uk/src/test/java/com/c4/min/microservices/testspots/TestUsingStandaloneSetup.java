package com.c4.min.microservices.testspots;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.c4.min.microservices.spots.Spot;
import com.c4.min.microservices.spots.SpotRepository;
import com.c4.min.microservices.spots.SpotsController;
import com.c4.mint.microservices.services.Main;
import com.c4.mint.microservices.services.spots.SpotsServer;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Main.class)
@WebAppConfiguration
@IntegrationTest("server.port:2222")
@EntityScan("com.c4.min.microservices.spots")
@EnableJpaRepositories("com.c4.min.microservices.spots")
@PropertySource("classpath:db-config.properties")
public class TestUsingStandaloneSetup{
	protected SpotRepository spotRepository;

	//@Autowired
    private final MockMvc mockMvc = MockMvcBuilders.standaloneSetup(new SpotsController(spotRepository)).build();
    @Test
    public void validate_getAllSpots() throws Exception {
    	Spot spot = new Spot();
    	spot.setAvailable("C4");
    	spot.setC4type("EB");
    	spot.setCert("2");
    	spot.setCh_terr("1206");
    	spot.setChannel("Y");
    	spot.setContract_title("A New life In The Sun");
    	spot.setId(5L);
    	spot.setNextschepi("NextSch1");
    	spot.setSchedule("Deal or No Deal");
    	spot.setSchepi("A New life In The Sun");
    	spot.setStart_time("21:00");
    	spot.setStatus("Closed");
    	spot.setTotal_cl("001:30");
    	spot.setTotal_sl("0003:30");
    	spot.setTrans_date("12-May-2016");
    	spot.setTrans_day("Monday");
    	
    	
    	
    	
    	
    	
    	
    	System.out.println("Hello");

        mockMvc.perform(get("/spots"))
                .andExpect(status().isOk())
                .andExpect(
                        content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.id").value("1"));
    }
}