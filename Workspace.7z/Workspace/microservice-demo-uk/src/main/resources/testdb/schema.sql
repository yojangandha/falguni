
drop table T_SPOT if exists;

create table T_SPOT (ID bigint identity primary key,
CH_TERR varchar(30),
NEXTSCHEPI varchar(30),
TRANS_DATE varchar(30),
TRANS_DAY varchar(30),
SCHEDULE varchar(30),
START_TIME varchar(30),
TOTAL_CL varchar(30),
TOTAL_SL varchar(30),
C4TYPE varchar(30),
SCHEPI varchar(30),
CERT varchar(30),
STATUS varchar(30),
AVAILABLE varchar(30),
CHANNEL varchar(30),
CONTRACT_TITLE varchar(30),
CONTRACT_TITLE_AFTER varchar(30));
                        
