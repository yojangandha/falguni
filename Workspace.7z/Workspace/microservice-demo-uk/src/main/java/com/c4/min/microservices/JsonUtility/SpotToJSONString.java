package com.c4.min.microservices.JsonUtility;

import org.codehaus.jackson.map.ObjectMapper;

import com.c4.min.microservices.spots.Spot;

public class SpotToJSONString {
	public static String getSpotAsString(Long spotId) throws Exception{
		Spot spot = new Spot();
    	spot.setAvailable("C4");
    	spot.setC4type("EB");
    	spot.setCert("2");
    	spot.setCh_terr("1206");
    	spot.setChannel("Y");
    	spot.setContract_title("A New life In The Sun");
    	spot.setId(spotId);
    	spot.setNextschepi("NextSch1");
    	spot.setSchedule("Deal or No Deal");
    	spot.setSchepi("A New life In The Sun");
    	spot.setStart_time("21:00");
    	spot.setStatus("Closed");
    	spot.setTotal_cl("001:30");
    	spot.setTotal_sl("0003:30");
    	spot.setTrans_date("12-May-2016");
    	spot.setTrans_day("Monday");
    	
    	ObjectMapper mapper = new ObjectMapper();
    	String data = mapper.writeValueAsString(spot);
    	return data;
		
	}

}
