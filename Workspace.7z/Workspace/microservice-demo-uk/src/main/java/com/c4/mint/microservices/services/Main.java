package com.c4.mint.microservices.services;

import org.springframework.boot.SpringApplication;

import com.c4.mint.microservices.services.spots.SpotsServer;

public class Main {

	public static void main(String[] args) {

		String serverName = "NO-VALUE";

		//TODO: remove switch 
		
		switch (args.length) {
		
		case 3: 
			System.setProperty("eureka.client.serviceUrl.defaultZone", args[2]);
			
		case 2:
			System.setProperty("server.port", args[1]);

		case 1:
			serverName = args[0].toLowerCase();
			break;

	
		default:
			return;
		}

		System.out.println("arg0 " + "serverName" + args[0].toLowerCase() + serverName);
		
		System.setProperty("spring.config.name", serverName + "-server");

		if (serverName.equals("spots")) {
			SpringApplication.run(SpotsServer.class, args);
		}  else {
			System.out.println("Unknown server type: " + serverName);
		}
	}
/**
 * 
 * 	GET /spots - Retrieves a list of spots
	GET /spots/12 - Retrieves a specific spot
	POST /spots - Creates a new spot
	PUT /spots/12 - Updates spot #12
	DELETE /spots/12 - Deletes spot #12

 * 
 * ***/
	
}
