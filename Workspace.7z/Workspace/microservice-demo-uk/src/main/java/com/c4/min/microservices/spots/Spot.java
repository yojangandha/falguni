package com.c4.min.microservices.spots;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "T_Spot")
public class Spot implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	protected Long id;
	
    
    @JsonProperty("Next Scedule Episode")
	protected String nextschepi;
    
    @JsonProperty("Ch- Territory")
	protected String ch_terr;

    @JsonProperty("Transmission Date")
	protected String trans_date;

    @JsonProperty("Day")
	protected String trans_day;
    
    @JsonProperty("Schedule")
	protected String schedule;

    @JsonProperty("Start Time")
    protected String start_time;
	
    @JsonProperty("Total CL")
	protected String total_cl;
	
    @JsonProperty("Total SL")
    protected String total_sl;
    @JsonProperty("Type")
	protected String c4type;
    @JsonProperty("Scheduled Episode")
	protected String schepi;
    @JsonProperty("Certificate")
	protected String cert;
    @JsonProperty("Status")
	protected String status;
    @JsonProperty("Available")
	protected String available;
    @JsonProperty("Channel")
	protected String channel;
    @JsonProperty("Contract Title")
	protected String contract_title;
    
    @JsonProperty("Contract Title After")
	protected String contract_title_after;
	
    public String getCh_terr() {
		return ch_terr;
	}
	public void setCh_terr(String ch_terr) {
		this.ch_terr = ch_terr;
	}
	public String getNextschepi() {
		return nextschepi;
	}
	public void setNextschepi(String nextschepi) {
		this.nextschepi = nextschepi;
	}
	public String getTrans_date() {
		return trans_date;
	}
	public void setTrans_date(String trans_date) {
		this.trans_date = trans_date;
	}
	public String getTrans_day() {
		return trans_day;
	}
	public void setTrans_day(String trans_day) {
		this.trans_day = trans_day;
	}
	public String getSchedule() {
		return schedule;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getTotal_cl() {
		return total_cl;
	}
	public void setTotal_cl(String total_cl) {
		this.total_cl = total_cl;
	}
	public String getTotal_sl() {
		return total_sl;
	}
	public void setTotal_sl(String total_sl) {
		this.total_sl = total_sl;
	}
	public String getC4type() {
		return c4type;
	}
	public void setC4type(String c4type) {
		this.c4type = c4type;
	}
	public String getSchepi() {
		return schepi;
	}
	public void setSchepi(String schepi) {
		this.schepi = schepi;
	}
	public String getCert() {
		return cert;
	}
	public void setCert(String cert) {
		this.cert = cert;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getContract_title() {
		return contract_title;
	}
	public void setContract_title(String contract_title) {
		this.contract_title = contract_title;
	}
	public String getContract_title_after() {
		return contract_title_after;
	}
	public void setContract_title_after(String contract_title_after) {
		this.contract_title_after = contract_title_after;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

}
