package com.aadityatiwari.java.scjp6.SCJPMOCK;

public class Q64 {
	
	private Q64(){} // A constructor can have any other access modified than the class
	
	public static void main(String[] args) {
		new Q64();
		int x =5;
		x = x++;
		System.out.println(x);
	}
	

}
