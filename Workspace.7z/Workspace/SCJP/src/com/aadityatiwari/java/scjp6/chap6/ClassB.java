package com.aadityatiwari.java.scjp6.chap6;

import java.io.Serializable;

public class ClassB extends ClassA implements Serializable {
	
	int bX;
	
	static {
		aS = 20;
		System.out.println("CLASS B :: STATIC BLOCK" + "A's STATIC var aS ="+aS);
	}
	
	{	
		bX = 10;
		System.out.println("CLASS B :: INSTANCE BLOCK" + "INSTANCE var bX ="+bX);
	}
	
	public ClassB() {
		super();
		System.out.println("CLASS B :: DEFAULT CONSTRUCTOR METHOD");
	}
	
	public ClassB(int x, int y) {
		this();
		aX =x;
		bX =y;
		System.out.println("CLASS B :: OVERLOADED CONSTRUCTOR METHOD, INSTANCE var bX ="+bX);
	}

	public int getbX() {
		return bX;
	}

	public void setbX(int bX) {
		this.bX = bX;
	}	
}
