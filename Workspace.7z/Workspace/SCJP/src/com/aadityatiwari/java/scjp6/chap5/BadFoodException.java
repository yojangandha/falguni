package com.aadityatiwari.java.scjp6.chap5;

import java.util.ArrayList;

public class BadFoodException extends Exception {
	
	public String checkFood(String name) throws BadFoodException
	{
		ArrayList<String> foodList = new ArrayList<String>();
		foodList.add("food1");
		foodList.add("food2");
		foodList.add("food3");
		
		for(String s : foodList)
		{
			if(name.equals(s))
				return "Good Food";
		}
		throw new BadFoodException();		
	}
}
