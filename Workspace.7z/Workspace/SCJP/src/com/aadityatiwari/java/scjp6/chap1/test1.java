package com.aadityatiwari.java.scjp6.chap1;

public class test1 {

	public static void main(String[] args) {
		ProtectedMemberInheritanceDummySubclass obj = new ProtectedMemberInheritanceDummySubclass();
		obj.fun2();
		// System.out.println(ProtectedMemberInheritance.x);
	}
}
