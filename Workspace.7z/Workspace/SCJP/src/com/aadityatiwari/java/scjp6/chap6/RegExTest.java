package com.aadityatiwari.java.scjp6.chap6;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExTest {
	
	public static void main(String[] args) {
		Pattern p = Pattern.compile(args[0]);
		Matcher m = p.matcher(args[1]);
		boolean b = false;
		System.out.println(" ------------------Pattern :: " +args[0] + "\t  Data String :: "+ args[1]+ "\t -----------------------");
		while ((b = m.find()))
		{
			//System.out.println("m.start : "+m.start() + "\t m.end : "+m.end() + "\t m.group: "+ m.group());
			System.out.print(m.start()+ m.group());
		}
	}

}
