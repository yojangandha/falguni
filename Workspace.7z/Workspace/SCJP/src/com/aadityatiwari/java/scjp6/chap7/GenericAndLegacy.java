package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;
import java.util.List;

public class GenericAndLegacy {	
	
	public static void main(String[] args) {
		List <Integer> myList = new ArrayList<Integer>();
		myList.add(4);
		myList.add(6);
		System.out.println("---------------- BEFORE -----------------");
		System.out.println(myList);
		Inserter in = new Inserter();
		in.insert(myList); // pass List<Integer> to legacy code
		//in.genericMetachar(myList);
		System.out.println("---------------- AFTER ------------------");
		System.out.println(myList);
	}
}
class Inserter 
{	// method with a non-generic List argument

	void insert(List list) {
		list.add(new Integer(42)); // adds to the incoming list
		list.add(new String("42"));
		list.add(new Object());
		list.add(2);
	}
	
	void insertGenericWay(List<Integer> list) {
		list.add(new Integer(42)); // adds to the incoming list
		//list.add(new String("42"));
		list.add((Integer)new Object());
	}
	
	void genericMetachar(List<Object> list)
	{
		//list.add("test");
		list.add(new Integer(50));
	}

}
