package com.aadityatiwari.java.scjp6.chap1;

public class ProtectedMemberInheritance {
	protected static int x=10;
	protected static String fun1(){
		
		return "Inside ProtectedMemberInheritance :: fun1 method : x = "+ProtectedMemberInheritance.x;
	}

}
