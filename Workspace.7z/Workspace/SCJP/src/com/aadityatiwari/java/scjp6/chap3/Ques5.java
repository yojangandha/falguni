package com.aadityatiwari.java.scjp6.chap3;

public class Ques5 {
	int i =5;
	static int ouch =7;
	
	public static void main(String[] args) {
		final Ques5 q1 = new Ques5();
		Ques5 q2 = new Ques5();
		Ques5 q3 = FuzzMethod(q1, q2);	
		System.out.println((q3==q1) + ", "+(q3.i==q1.i));
		new Ques5().go(ouch);
		System.out.println("Ouch = "+ouch);
	}
	
	static Ques5 FuzzMethod(Ques5 x, Ques5 y)
	{
		final Ques5 z = x;
		z.i = 6;
		return z;
	}
	
	void go(int ouch)
	{
		ouch++;
		for(ouch =3;ouch<6;ouch ++);
		System.out.println(ouch);
	}

}
