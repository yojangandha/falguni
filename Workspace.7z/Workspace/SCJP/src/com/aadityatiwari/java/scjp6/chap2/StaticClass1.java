package com.aadityatiwari.java.scjp6.chap2;


public class StaticClass1 extends StaticClass2
{
	
	public static void main(String[] args) {
//		System.out.println("From StaticClass1, abc = "+abc);
//		fun();
//		System.out.println("StaticClass1.abc = "+StaticClass1.abc);		
		StaticClass2 obj = new StaticClass1();
		obj.instanceMethod();
		obj.fun();
		((StaticClass1)obj).fun();
		fun();
	}
	
	static void fun()
	{
		System.out.println("StaticClass1's string abc = "+ abc);
	}
	public void instanceMethod() {
        System.out.println("instanceMethod() in StaticClass1");
    }
}
