/**
 * 
 */
package com.aadityatiwari.java.scjp6.chap2;

import java.io.*;

/**
 * @author atiwari32
 *
 */
public class Test2 extends Test1{

//	public String eat(){
//		System.out.println("TEST2 : eat() ");
//	}
	public void eat(){
		System.out.println("TEST2 : eat() ");
	}
	
	public void eat(String str){
		System.out.println("TEST2 : eat() ");
	}
	
	public void fun1() throws NullPointerException
	{
		System.out.println(" throws NullPointer Exception");
	}
	public void fun1(int a)
	{
		System.out.println(a+" throws nothing/anything");
	}
	public String fun1(String str)
	{
		System.out.println(str+" throws nothing/anything");
		return "";
	}
	public static void main(String[] args) {
		//Test2 obj = new Test2();
		Test1 t1Obj2 = new Test2();
//		obj.eat();
//		obj.fun1();
//		obj.fun1(1);
//		obj.fun1("fun1() ");
		t1Obj2.eat();
	}

}
