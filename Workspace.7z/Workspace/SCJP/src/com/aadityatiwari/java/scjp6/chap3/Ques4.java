package com.aadityatiwari.java.scjp6.chap3;

public class Ques4 {
	
	Ques4() { }
	Ques4(Ques4 q) { 
		q1 = q;
	}
	Ques4 q1;
	
	public static void main(String[] args) {
		Ques4 q2 = new Ques4();
		Ques4 q3 = new Ques4(q2);
		q3.go();
		Ques4 q4 = q3.q1;
		q4.go();
		Ques4 q5 = q2.q1;
		q5.go();
	}
	
	void go()
	{
		System.out.println("hi ");
	}
}
