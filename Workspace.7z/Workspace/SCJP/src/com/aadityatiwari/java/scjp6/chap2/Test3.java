package com.aadityatiwari.java.scjp6.chap2;

public class Test3 {

	public void funBegins(Test1 obj)
	{
		System.out.println("funBegins for TEST1");
	}
	public void funBegins(Test2 obj)
	{
		System.out.println("funBegins for TEST2");
	}
	
	public static void main(String[] args) {
		Test1 ob1 = new Test1();
		//Test1 ob1 = new Test2();
		Test2 ob2 = new Test2();
		Test3 ob3 = new Test3();
		ob3.funBegins(ob1);
		ob3.funBegins(ob2);	
	
	}

}
