package com.aadityatiwari.java.scjp6.chap1;

public interface InterfaceToTestInstanceVariable {
	int i=10;
	void met1();

}
