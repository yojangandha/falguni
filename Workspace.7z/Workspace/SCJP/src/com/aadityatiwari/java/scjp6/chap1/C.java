package com.aadityatiwari.java.scjp6.chap1;

interface A {
	  String X = "foo";
	}

	interface B {
	  String X = "bar";
	}

	interface C extends A, B {

	//public static void funC();
	}