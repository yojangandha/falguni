package com.aadityatiwari.java.scjp6.chap7;

	public class Ques6 {
		public static void main(String[] args) {}
	}
	interface Hungry<E> { void munch(E x); }
	interface Carnivore<E extends Animal> extends Hungry<E> {}
	interface Herbivore<E extends Plant> extends Hungry<E> {}
	abstract class Plant {}
	class Grass extends Plant {}
	abstract class Animal {}
		class Sheep extends Animal implements Herbivore<Grass> {
		//public void munch(Sheep x) {}
		public void munch(Grass x) {}
		}
//		class Sheep extends Animal implements Herbivore<Plant> {
//			public void munch(Plant x) {}
//			public void munch(Grass x) {}
//		}
//	class Sheep extends Plant implements Carnivore<Wolf> {
//		public void munch(Wolf x) {}
//		}
//	
	class Wolf extends Animal implements Carnivore<Sheep> {
	public void munch(Sheep x) {}
	}
