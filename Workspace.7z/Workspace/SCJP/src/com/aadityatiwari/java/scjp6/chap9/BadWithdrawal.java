package com.aadityatiwari.java.scjp6.chap9;

public class BadWithdrawal implements Runnable{
	Account account = new Account();
	
	public static void main(String[] args) {
		BadWithdrawal obj = new BadWithdrawal();
		Thread A = new Thread(obj);
		Thread B = new Thread(obj);
		A.setName("A");
		B.setName("B");
		A.start();
		B.start();		
	}
	
	public void run()
	{
		for (int x = 0; x < 6; x++) {
			makeWithdrawal(10);
			if (account.getBalance() < 0) {
				System.out.println("account is overdrawn!");
			}
		}
		
	}

	private synchronized void  makeWithdrawal(int amount) {		
		if(account.getBalance()>amount)
		{
			System.out.println(Thread.currentThread().getName()+ " is going to make a withdrawal");
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				System.out.println("InterruptedException inside wait");
			}
			account.withdraw(amount);
			System.out.println(Thread.currentThread().getName()+ 
				"'s withdrawal complete. Remaining Balance :: "+account.getBalance());
		}
		else
		{
			System.out.println("Insufficient balance ("+account.getBalance()+ 
					") for Thread "+Thread.currentThread().getName());
		}
		
	}
	
}
