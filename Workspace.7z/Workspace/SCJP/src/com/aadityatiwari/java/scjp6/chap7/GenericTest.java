package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;
import java.util.List;

public class GenericTest {
	
	public static void main(String[] args) {
	
		List <Integer> myList = new ArrayList<Integer>();
		myList.add(4);
		myList.add(6);
		
		System.out.println("--------------------BEFORE Insertion-------------------");
		System.out.println(myList);
		
		Insertor in = new Insertor();
		in.insert(myList);
		
		System.out.println("--------------------AFTER Insertion--------------------");
		System.out.println(myList);
	}

}

class Insertor {
	
	public void insert(List list)
	{
		list.add(new Integer(42));
		list.add(new String("43"));
		list.add("44");
	}
}
