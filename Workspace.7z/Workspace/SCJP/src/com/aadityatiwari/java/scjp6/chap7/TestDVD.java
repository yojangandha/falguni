package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;
import java.util.Collections;

public class TestDVD {
	
	ArrayList<DVDInfo> dvdList = new ArrayList<DVDInfo>();
	
	public static void main(String[] args) {
		
		TestDVD obj = new TestDVD();
		obj.populateList();
		System.out.println("\nUNSORTED -------->>\n" + obj.dvdList);
		Collections.sort(obj.dvdList);
		System.out.println("\n\nSORTED -------->>\n" + obj.dvdList);
	}
	
	public void populateList()
	{
		dvdList.add(new DVDInfo("The Dark Knight", "Action", "Christian Bale"));
		dvdList.add(new DVDInfo("Into the wild", "Adventure", "Emile Hursch"));
		dvdList.add(new DVDInfo("Indian Jones 4", "Adventure", "Harrison Ford"));
		dvdList.add(new DVDInfo("Star Wars", "Action", "Harrison Ford"));
	}

}
