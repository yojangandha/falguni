package com.aadityatiwari.java.scjp6.practiceExam1;

import java.util.Arrays;
import java.util.Comparator;

public class Q38StaticInnerClass {
	
	
	public static void main(String[] args) {
		String[] towns = {"Manhattan","Pennsylvenia","LA","LasVegas","AtlanticCity"};
		Mysort ms = new Mysort();
		Arrays.sort(towns, ms);
		//System.out.println(towns.toString());
		for(String s:towns)
			System.out.print(s+" ");
		System.out.println("\n"+Arrays.binarySearch(towns, "LA"));

	}
	static class Mysort implements Comparator<String>
	{

		@Override
		public int compare(String o1, String o2) {
			// TODO Auto-generated method stub
			
			return o2.compareTo(o1);
		}
		
		
	}

}
