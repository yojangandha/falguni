package com.aadityatiwari.java.scjp6.SCJPMOCK;

public enum Q6 {
	BREAKFAST , LUNCH ,  DINNER;
	public static void main(String[] args) {
		Q6 var  = BREAKFAST;
		Q6 var2 = Q6.LUNCH;
		System.out.println(var + " " + var2);
		System.out.println(010 +  " : " + 000000000000017);
	}

}
