package com.aadityatiwari.java.scjp6.selfassesment.at1;

import java.util.List;

public class Q3 extends Thread implements testInterface{

	
	public static void main(String[] args) {
		
		Thread t = new Thread(new Q3());
		//Thread t2 = new Thread(new Q3());
		System.out.println(Thread.currentThread().getId()+ " ");
		float d = (float)3.2;
		System.out.format("%f",	d);
		
		t.setPriority(1);
		t.setName("t");
		t.start();
		
		//t2.setPriority(1);
		//t2.setName("t2");		
		//t2.start();
		new Q3().run();

	}
	public void run()
	{
		for(int i=0;i<2;i++)
			//System.out.print("NAME:"+Thread.currentThread().getName()+",ID:"+Thread.currentThread().getId()+ " ");
			System.out.print("NAME:"+Thread.currentThread().getName()+ "-"+i+" ");
	}
	
	public List<String> doStuff(List<String> s)
	{
		int x =0;
		s.add("");
		return s;
	}

}

interface testInterface
{
	List<String> doStuff(List<String> s);
}
