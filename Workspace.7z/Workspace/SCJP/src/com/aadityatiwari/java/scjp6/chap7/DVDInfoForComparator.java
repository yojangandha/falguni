package com.aadityatiwari.java.scjp6.chap7;

import java.util.Comparator;

public class DVDInfoForComparator {
	
	String title;
	String genre;
	String leadActor;
	
	public DVDInfoForComparator(String t, String g, String a)
	{
		title =t;
		genre = g;
		leadActor = a;
	}
	public String toString()
	{
		return "Title : " +title + "; Genre : " + genre + "; Actor : " + leadActor + "\n";
	}		
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getLeadActor() {
		return leadActor;
	}
	public void setLeadActor(String leadActor) {
		this.leadActor = leadActor;
	}	
	
}
