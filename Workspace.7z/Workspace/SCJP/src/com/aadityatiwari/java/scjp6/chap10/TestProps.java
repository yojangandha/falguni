package com.aadityatiwari.java.scjp6.chap10;
//import java.*;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
public class TestProps {	
	public Properties p = System.getProperties();
    	
	public static void main(String[] args) {
		TestProps obj = new TestProps();
		System.out.println(obj);
	}
	public synchronized String toString() {
        int max = this.p.size() - 1;
        if (max == -1)
            return "{}";

        StringBuilder sb = new StringBuilder();
        Iterator it = this.p.entrySet().iterator();

        sb.append('{');
        int i=0;
        while(it.hasNext()) {
            //HashTable hTable = new HashTable<String, String>();
        	String[] str = it.next().toString().split("=");
        	//System.out.println(""+str[0]+ " => "+str[1]);
            //String key = str[0];
            //String value = str[1];
        	//sb.append(key);
        	sb.append(str[0]);
        	sb.append('=');
        	if(str.length==2)
        	{
        		sb.append(str[1]);
        	}
            

            if (i == max)
                {	System.out.println("i is max, i = "+i);
            	return sb.append('}').toString();}
            sb.append(",\n ");
            i++;
        }
        return sb.toString();
	}
}