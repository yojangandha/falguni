package com.aadityatiwari.java.scjp6.selfassesment.at2;

public class EnumTestQ4 {

	public static void main(String[] args) {
		System.out.println("From 'main' : " + Weather2.HOT);
		// System.out.println("From 'main' : "+Weather.SUNNY);
	}
}

enum Weather2 {
	RAINY, SUNNY, HOT;
	// WHATEVER;
	int count = 0;

	Weather2() {
		System.out.println("Inside Constructor, Count : "
				+ (++Weather2.this.count) + " ");
	}
}
