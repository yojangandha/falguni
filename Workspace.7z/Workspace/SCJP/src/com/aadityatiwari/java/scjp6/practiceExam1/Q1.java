package com.aadityatiwari.java.scjp6.practiceExam1;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Q1 extends Thread{
	static Thread t1, t2, t3;
	
	{System.out.println("Q1 Instance Block");}
	
	public Q1()
	{
		System.out.println("Q1 Constructor Block");
		try {
			finalize();
			finalize();
			finalize();
		} 
		catch (FileNotFoundException e) {}
		catch (IOException e) {}
		catch (Throwable t) {}
		
	}
	
	public static void main(String[] args) throws Exception {
		
		t1 = new Thread(new Q1());
		t2 = new Thread(new Q1());
		t3 = new Thread(new Q1());
		//t1.start(); t2.start(); t3.start();
	
	if(false)
		try {
				System.out.println("true IF");
				System.out.println("true IF 2nd Line");
			}
		catch (Exception e) { }
		System.out.println("After catch");
	}
	public void run() {
	for(int i = 0; i < 500; i++) {
		System.out.print(Thread.currentThread().getId() + " ");
			if(i == 250)
				try {
				System.out.print("**" + t1.getId() + "**");
				t1.sleep(600);
				}
	catch (Exception e) { }
		}
	} 
}

