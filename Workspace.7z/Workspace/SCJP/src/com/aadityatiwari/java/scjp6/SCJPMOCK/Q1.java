package com.aadityatiwari.java.scjp6.SCJPMOCK;

//public class Q1 {
//
//	public static void main(String[] args) {
//
//
//	}
//
//}
class A {
	int commonVar =10;
	static int commonStaticVar = 1;
	int add(int i, int j){
		return i+j;
	}
}
public class Q1 extends A {
//	int var;
//	int $p;
//	int £q;
//	int ___;
	//int __p;
	int commonVar =12;
	static int commonStaticVar = 2;
	public static void main(String[] args) {
		//short s=1;
		double s=1;
		int x=new Q1().add((int)s, (int)3.0);
		System.out.println(x);
		//System.out.println(new Q1().var);
		A a = new Q1();
		System.out.println("a.commonVar : "+a.commonVar); // rum-time polymorphism applies only to methods
		System.out.println("new Q1().commonVar : "+new Q1().commonVar);
		System.out.println("new Q1().commonStaticVar : "+new Q1().commonStaticVar);
		System.out.println("new A().commonStaticVar : "+new A().commonStaticVar);
		System.out.println("Q1.commonStaticVar : "+Q1.commonStaticVar);
		System.out.println("A.commonStaticVar : "+A.commonStaticVar);
	}

}
