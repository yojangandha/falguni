package com.aadityatiwari.java.scjp6.chap5;

public class CustomException {
	
	public static void main(String[] args) {
		String result;
		if(args.length==1 && args[0]!="")
		{			
			BadFoodException ex = new BadFoodException();			
			try {
				result = ex.checkFood(args[0]);
				System.out.println("GOOD FOOD, No Exception !!");
			} catch (BadFoodException e) {
				// TODO Auto-generated catch block
				System.out.println("JUST CAUGHT BadFoodException !! ");
			}
		}
	}
}
