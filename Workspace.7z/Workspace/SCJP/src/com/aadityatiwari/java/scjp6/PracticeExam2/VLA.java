package com.aadityatiwari.java.scjp6.PracticeExam2;

import java.util.Arrays;
import java.util.Comparator;

public class VLA implements Comparator<VLA> {
	int dishSize;	
	public static void main(String[] args) {
		
		VLA[] va = {new VLA(40), new VLA(40), new VLA(200), new VLA(60)};
		System.out.println("1 - PRINT the dishSize of all the elements in array : ");
		for(VLA v: va) System.out.print(v.dishSize+" ");
		int index = Arrays.binarySearch(va, new VLA(40),va[0]);
		System.out.println("\nIndex for Arrays.binarySearch(va, new VLA(40),va[0]) is "+ index);
		index = Arrays.binarySearch(va, new VLA(700),va[0]);
		System.out.println("Index for Arrays.binarySearch(va, new VLA(700),va[0]) is "+ index);
		
		System.out.println("Test 2: >>> operator : they say it's an unsigned right shift operator");
		int x = 256;
		x=x>>>1;
		System.out.println("x = "+x);
		x=x<<1;
		System.out.println("x = "+x);

	}

	@Override
	public int compare(VLA o1, VLA o2) {
		return o1.dishSize - o2.dishSize;
	}
	VLA(int d)
	{
		dishSize=d;
	}

}
