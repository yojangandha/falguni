package com.aadityatiwari.java.scjp6.chap5;

public class Exercise2 {

	static int age;
	public static void main(String[] args) {		
		
		outer:
			while(age<=21)
			{
				age++;
				if(age ==16){
					System.out.println("Get your driver's License : "+age);
					continue outer;
				}
				System.out.println("Another year " + age);
			}
	
		System.out.println("testFinally() returns "+testFinally());
	}
	public static int testFinally()
	{
		try{System.out.println("try");return 5;}
		//catch(Exception e){System.out.println("catch");}
		finally{System.out.println("finally");}
		//return 1;
	}

}
