package com.aadityatiwari.java.scjp6.chap7;

public class ReverseInt {

	
	public static void main(String[] args) {
		int count = 1, j = 0,i= Integer.parseInt(args[0]);
		int digits =0;
		int temp =i;
		
		while(temp>0)
		{
			temp/=10;
			digits++;
			count*=10;
		}		
		System.out.println("Input= "+i);
		System.out.println("Digits= "+digits);
		System.out.println("Count= "+count);
		
		while(true)
		{
			//System.out.println("hi");
			int rem = i%10;
			int quo = i/10;
			count/=10;
			j+=count*rem;
			i/=10;
			digits--;
			if(digits==0) break;
		}
		System.out.println("Output= "+j);
		}

	}
