package com.aadityatiwari.java.scjp6.revision;

import java.lang.Enum;
import java.util.ArrayList;

interface InterFace {
	void fun1();
}

class ClassWhichImplemetsInterFace implements InterFace{
	public void fun1() {}
}
public class A extends ClassWhichImplemetsInterFace implements InterFace{

	enum Days {
		WED("WED"),THU("THU"),FRI("FRI");
		
		String day;
		Days(String str){
			day =str;
		}
		
		public static void printDays() {
			Days[] dArray = Days.values();
			for(Days d : dArray) {
				System.out.print(d.day+" ");
			}
			//return "";
		}
	}
	public static void main(String[] args) {
		
		Days.printDays();
		System.out.println("\n\n---------Again\n");
		
		for(Days d : Days.values()){
			System.out.print(d.day+ " ");
		}
		
		//ArrayList<E>

	}

}

//class B extends A implements InterFace {}
