package com.aadityatiwari.java.scjp6.SCJPMOCK;

public class Q46 {
	
	public static void main(String[] args) {
		Q46_A a = new Q46_A();
		a.start();
//		try {
//			a.join();
//		} catch (InterruptedException e1) {
//			e1.printStackTrace();
//		}
		synchronized(a){
			System.out.println("Main thread waiting ...");
			try {
				a.wait(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("a.count : "+a.count);
		}

	}

}

class Q46_A extends Thread {
	int count=0;
	public void run(){
		System.out.println("run");
		synchronized(this){
			try {
				sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			for(int i =0;i<50;i++)
				count = count + i;
			//notify();
		}
	}
}
