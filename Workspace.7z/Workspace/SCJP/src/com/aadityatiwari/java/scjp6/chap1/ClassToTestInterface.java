package com.aadityatiwari.java.scjp6.chap1;

public class ClassToTestInterface implements InterfaceToTestInstanceVariable, C{
	public void met1() {
		//this.i=11;
		//System.out.println(C.X);
	}
}
