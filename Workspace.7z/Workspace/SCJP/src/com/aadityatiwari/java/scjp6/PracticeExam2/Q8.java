package com.aadityatiwari.java.scjp6.PracticeExam2;

import java.util.Iterator;
import java.util.TreeSet;

public class Q8 {
	
	public static void main(String[] args) {
		
		TreeSet<Integer> t = new TreeSet<Integer>();
		t.add(20); t.add(30); t.add(2);		
		Iterator i = t.iterator();
		
		//for(Integer j : i)
			// System.out.print(j+" ");
		args[0] = "x";
		
		for(Integer j : t)
			System.out.print(j+" ");
		System.out.println();
		
		if(args[0].equals("x"));
			System.out.println("x");
		if(args[0] == "x");
			System.out.println("x2");
			
			try{throw new Exception(); //System.out.println("Try");
				}
			catch(Exception e){System.out.println("Catch");}
			finally{System.out.println("Finally");}
			System.out.println("YoYo after finally");
		

	}

}
