package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;
import java.util.Collections;

public class TestDVDForComparator {
ArrayList<DVDInfoForComparator> dvdListComparator = new ArrayList<DVDInfoForComparator>();
//ArrayList<DVDInfoForComparator> dvdListComparatorII = new ArrayList<DVDInfoForComparator>();
	
	public static void main(String[] args) {
		TestDVDForComparator obj = new TestDVDForComparator();
		obj.populateList();
		System.out.println("\nUNSORTED -------->>\n" + obj.dvdListComparator);
	//Collections.sort(obj.dvdListComparator, new TitleSort());
		Collections.sort(obj.dvdListComparator, new ActorSort());
		System.out.println("\n\nSORTED -------->>\n" + obj.dvdListComparator);
	}
	
	public void populateList()
	{
		dvdListComparator.add(new DVDInfoForComparator("The Dark Knight", "Action", "Christian Bale"));
		dvdListComparator.add(new DVDInfoForComparator("Into the wild", "Adventure", "Emile Hursch"));
		dvdListComparator.add(new DVDInfoForComparator("Indian Jones 4", "Adventure", "Harrison Ford"));
		dvdListComparator.add(new DVDInfoForComparator("Star Wars", "Action", "Harrison Ford"));
		
//		dvdListComparatorII.add(new DVDInfoForComparator("The Dark Knight", "Action", "Christian Bale"));
//		dvdListComparatorII.add(new DVDInfoForComparator("Into the wild", "Adventure", "Emile Hursch"));
//		dvdListComparatorII.add(new DVDInfoForComparator("Indian Jones 4", "Adventure", "Harrison Ford"));
//		dvdListComparatorII.add(new DVDInfoForComparator("Star Wars", "Action", "Harrison Ford"));
	}
}
