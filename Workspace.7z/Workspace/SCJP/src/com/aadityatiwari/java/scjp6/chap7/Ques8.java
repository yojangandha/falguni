package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;
import java.util.List;

public class Ques8 {

	public static void main(String[] args) {	
		ArrayList<Integer> input = null;
		ArrayList<Integer> output = null;
		input = new ArrayList<Integer>();
		input.add(0);
		output = (ArrayList)process(input);
		System.out.println("Input : "+input);
		System.out.println("Output : "+output);
	}
	
	public static <E extends Number> List<E> process(List<E> nums)
	{		
		//nums = new ArrayList<E>();
		nums.add((E)new Integer(1));
		System.out.println("" + //shite
				"yoyo");
		return nums;
	}
}
