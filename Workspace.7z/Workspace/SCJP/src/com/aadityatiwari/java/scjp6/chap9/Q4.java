package com.aadityatiwari.java.scjp6.chap9;

public class Q4 {

	public static void main(String[] args) throws InterruptedException{
		System.out.print("1 ");
		DummyThread t = new DummyThread(args);
		t.start();
		//synchronized (args) {
			System.out.print("2 ");
			args.wait();
//			try {
//				//t.start();
//				args.wait();
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
	//}
		System.out.println("3 ");
	}

}

class DummyThread extends Thread {
	 String[] args;
	public void run()
	{
		synchronized (args) {
			args.notify();
		}
	}
	public DummyThread(String[] args)
	{
		this.args=args;
	}
}
