package com.aadityatiwari.java.scjp6.revision;

public class UpDownRefCasting extends Parent{

	public static void main(String[] args) {
		
		((Parent)new UpDownRefCasting()).fun1();
		//((Parent)new UpDownRefCasting()).fun2();
		((UpDownRefCasting)new Parent()).fun1();

	}
	
	public void fun2(){ 
		System.out.println("fun2");
	}

}

class Parent {
	
	public void fun1(){ 
		System.out.println("fun1");
	}
}
