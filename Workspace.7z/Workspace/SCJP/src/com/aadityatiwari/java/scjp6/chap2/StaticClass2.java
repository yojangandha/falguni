package com.aadityatiwari.java.scjp6.chap2;


class StaticClass2 {
	
	static String abc = "abc";
	static void fun()
	{
		System.out.println("StaticClass2's string abc = "+ abc);
	}
	public void instanceMethod() {
        System.out.println("instanceMethod() in StaticClass2");
    }
}