package com.aadityatiwari.java.scjp6.chap8;

public class InnerClassTest {

	public static void main(String[] args) {
		

	}

}
