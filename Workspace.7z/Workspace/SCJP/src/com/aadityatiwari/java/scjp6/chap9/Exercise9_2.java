package com.aadityatiwari.java.scjp6.chap9;

public class Exercise9_2 {
	
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("A");
		MySyncThread t1 = new MySyncThread(sb);
		MySyncThread t2 = new MySyncThread(sb);
		MySyncThread t3 = new MySyncThread(sb);
		System.out.println("HASHCODE : ORIGINAL sb : "+sb.hashCode());
		t1.setName("t1");
		t2.setName("t2");
		t3.setName("t3");
		
		t1.start();
		t2.start();
		t3.start();

	}
}

class MySyncThread extends Thread
{	StringBuffer sb = new StringBuffer();
	
	public MySyncThread(StringBuffer sb)
	{
		this.sb=sb;
	}
	
	public void run()
	{
		synchronized (sb)
		{
			System.out.println("HASHCODE : run() sb : "+sb.hashCode()+" Thread Name :: "+Thread.currentThread().getName());
			for(int i=0;i<10;i++)
			{
				System.out.print(sb+"\t");
			}
			sb.setCharAt(0, (char)(sb.charAt(0)+1));
			System.out.println();
		}
	}
	
}