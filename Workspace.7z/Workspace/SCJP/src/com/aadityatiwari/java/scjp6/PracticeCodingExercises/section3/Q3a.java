package com.aadityatiwari.java.scjp6.PracticeCodingExercises.section3;

public class Q3a {
	
	public static void main(String[] args) {
		Integer obj1 = new Integer(1);
		
		System.out.println("obj1.doubleValue() : "+obj1.doubleValue());
		String obj2 = new String("2");
		System.out.println("obj2.doubleValue() : "+String.valueOf(3));
		System.out.println("Integer.parseInt(obj2): "+Integer.parseInt(obj2));
		System.out.println("Float.parseFloat(obj2): "+Float.parseFloat(obj2));
		System.out.println("Long.parseLong(obj2): "+Long.parseLong(obj2));
		

	}

}
