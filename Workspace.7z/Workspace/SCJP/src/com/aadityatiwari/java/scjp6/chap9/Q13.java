package com.aadityatiwari.java.scjp6.chap9;

public class Q13 implements Runnable {
	void go(long id, String name)
	{
		System.out.print("Name : "+name);
		System.out.print(", ID : "+id);
	}
	
	public static void main(String[] args) {
		System.out.println("Name : "+Thread.currentThread().getName() + ", ID : " + Thread.currentThread().getId());
		//new Q13().run();
		//new Q13().start();
		//new Thread(new Q13());
		//new Thread(new Q13()).run();
		new Thread(new Q13()).start();
		
	}
	public void run(){
		go(Thread.currentThread().getId(), Thread.currentThread().getName());
	}

}
