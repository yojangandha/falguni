package com.aadityatiwari.java.scjp6.chap1;

public class ProtectedMemberInheritanceDummySubclass extends
		ProtectedMemberInheritance {

	// public static void main(String[] args) {
	// ProtectedMemberInheritanceDummySubclass obj = new
	// ProtectedMemberInheritanceDummySubclass();
	// obj.fun2();
	// }
	public void fun2() {
		System.out.println("Value of Inherited x before changing : " + this.x);
		x = 20;
		System.out.println("Value of Inherited x after changing : "
				+ ProtectedMemberInheritance.x);
		// ProtectedMemberInheritance obj = new ProtectedMemberInheritance();
		System.out.println(ProtectedMemberInheritanceDummySubclass.fun1());
	}
}
