package com.aadityatiwari.java.scjp6.at1;

import java.util.ArrayList;
import java.util.List;

public class ChoosyQ5 {
	
	public static void main(String[] args) {
	String result = "";
	int x = 7, y = 8;
	if(x == 3) { result += "1"; }
	else if (x > 9) { result += "2"; }
	else if (y < 9) { result += "3"; }
	else if (x == 7) { result += "4"; }
	else { result += "5"; }
	System.out.println(result+ "\nSTRING BUFFER PROCESSING \n ");
	
	StringBuffer sb = new StringBuffer("hi");
	StringBuffer sb2 = new StringBuffer("hi");
	StringBuffer sb3 = new StringBuffer(sb);
	StringBuffer sb4 = sb;
	System.out.println(sb.hashCode());
	System.out.println(sb2.hashCode());
	System.out.println(sb4.hashCode());
	System.out.println(sb4.equals(sb));	
	System.out.println(result+ "\nSTRING HashCode PROCESSING \n ");
	String s1 = "hiqqqqqqqqqqqqqqqqqqqqqqqqq";
	String s2 = "hiqqqqqqqqqqqqqqqqqqqqqqqqq";
	System.out.println(s1.hashCode());
	System.out.println(s2.hashCode());
	System.out.println(s1.equals(s2));
//	List <A> l1= new ArrayList<B>();
//	List <B> l2= new ArrayList<A>();
//	List <Object> l3= new ArrayList<A>();
	List <A> l4= new ArrayList<A>();
	B b = new B();
	}
	
}

abstract class alpha 
{
	public alpha()
	{
		System.out.println("INSIDE alpha() constructor method");
	}
}
class A extends alpha {
	
	public A()
	{
		System.out.println("INSIDE A() constructor method");
	}
}
class B extends A 
{
	
}

