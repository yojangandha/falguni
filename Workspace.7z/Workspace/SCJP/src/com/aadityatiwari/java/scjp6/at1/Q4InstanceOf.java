package com.aadityatiwari.java.scjp6.at1;

public class Q4InstanceOf extends Parent {

	public static void main(String[] args) {
		Parent p = new Parent();
		Q4InstanceOf q4 = new Q4InstanceOf();
		if(q4 instanceof Parent)
			System.out.println();
	}

}
class Parent {}
