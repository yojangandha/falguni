package com.aadityatiwari.java.scjp6.chap9;

public class Q10 extends Thread {

	public Q10 ()
	{
		System.out.println(" Q10 THREAD");
	}
	
	public void testMethod()
	{
		System.out.println(" Inside testMethod");
	}
	
	public static void main(String[] args) {
		Thread t= new Q10() {
			public void run() 
			{
				System.out.println(" foo");
				testMethod();
			}
			public void testMethod()
			{
				System.out.println(" Inside overridden testMethod");
			}
		};
		//t.testMethod();
		//t.start();
		t.run();

	}

}
