package com.aadityatiwari.java.scjp6.chap4;



public class Ques3 {
	
	public static void main(String[] args) {
		//System.out.println(args.length);
		//System.out.println(args[0].toString());
//		if(args.length == 1 | args[0].equals("test"))
//			System.out.println("test case");
//		else 
//			System.out.println("Production "+ args[0]);
		
		
}
}
