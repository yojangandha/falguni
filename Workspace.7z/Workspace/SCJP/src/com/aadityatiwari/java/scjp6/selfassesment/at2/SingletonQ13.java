package com.aadityatiwari.java.scjp6.selfassesment.at2;


class MyThread2 extends Thread
{	private int code;
	public void run()
	{	SafeDeposit obj1;
		System.out.println("BEGIN :: Inside MyThread's run(), code= "+code+" Name: "+Thread.currentThread().getName());
			obj1 = SafeDeposit.getInstance(1);
		System.out.println("END :: Inside MyThread's run(), SafeDeposit's instance HashCode= "+obj1.hashCode()+" Name: "+Thread.currentThread().getName());
	}
  
	MyThread2(int x)
  	{
		code =x;
		System.out.println("MyThread's CONSTRUCTOR, code = "+code);
  	}
}


public class SingletonQ13 {

	
	public static void main(String[] args) {
		MyThread2 obj = new MyThread2(10);
		MyThread2 obj2 = new MyThread2(20);
		Thread t1 = new Thread(obj);
		Thread t2 = new Thread(obj2);
		System.out.println("MAIN:: Before Thread's Launch");
		t1.setName("t1");
		t2.setName("t2");
		t1.start();
		t2.start();
		
		//SafeDeposit obj1 = SafeDeposit.getInstance(1);
		//SafeDeposit obj2 = SafeDeposit.getInstance(2);
		//System.out.println("Hashcode : t1>"+obj1.getCode() + ", Hashcode : obj2>"+obj2.getCode());
		//System.out.println(obj1.equals(obj2));
	}

}

class SafeDeposit
{
	private static SafeDeposit singleton;
	private int code;
	
	public static synchronized SafeDeposit getInstance(int code){
//		try {
//			Thread.sleep(500);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
		if(singleton==null)
			singleton = new SafeDeposit(code);
		return singleton;
	}
	private SafeDeposit(int c)
	{
		code =c;
	}
	
	int getCode()
	{
		return code;
	}
	
}

