package com.aadityatiwari.java.scjp6.PracticeCodingExercises.section3;

/** Singleton class*/

class singletonClass {
	private static singletonClass obj;
	public int x;
		
		private singletonClass(int y){x=y;}
		
		public static singletonClass getInstance(int y)
		{
			if(obj==null)
				obj = new singletonClass(y);
			return obj;
		}
}

public class Q5e {	
	public static void main(String... args) {
		singletonClass obj = singletonClass.getInstance(1);
		singletonClass obj2 = singletonClass.getInstance(2);
		singletonClass obj3 = singletonClass.getInstance(3);
		//singletonClass obj3 = new singletonClass();
		
		System.out.println(obj.hashCode()+" : "+obj2.hashCode()+" : "+obj3.hashCode());
		System.out.println(obj.x+" : "+obj2.x+" : "+obj3.x);
				
		if(0x11 == 17)
		{
			System.out.println("\nHexa compared : both equals 17");
		}
		if(011 == 9)
		{
			System.out.println("octal compared : both equals 9");
		}
		String hashCode = "ddd";
		
		System.out.println(hashCode.hashCode());
		
		if(hashCode == "x") System.out.println(" == valid");
	}

}
