package com.aadityatiwari.java.scjp6.chap9;

public class Exercise9_1 {

	public static void main(String[] args) {
		MyThread t = new MyThread();
		t.start();
		t.start();

	}

}

class MyThread extends Thread 
{
	public void run()
	{
		for(int i=1;i<=100;i++)
		{
			System.out.print(i+"\t");
			int rem = i%10;
			if(rem==0){
				System.out.println();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					System.out.println("InterruptedException");
				}
			}
				
		}
	}
}
