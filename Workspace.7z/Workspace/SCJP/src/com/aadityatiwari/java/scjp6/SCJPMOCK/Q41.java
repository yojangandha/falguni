package com.aadityatiwari.java.scjp6.SCJPMOCK;

public class Q41 extends Thread{

	public static void main(String[] args) {
		Q41 t  = new Q41();
		Thread t2 = new Thread(t,"t2");
		t.run();
		t.start();
		t2.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		System.out.println("MAIN Ends");
	}
	public void run(){
		System.out.println(" RUN "+Thread.currentThread().getName());
	}

}
