package com.aadityatiwari.java.scjp6.revision;

import java.io.IOException;

public class OvridingMethCheckedEx extends Chap2test{

	public static void main(String[] args) {
		
		Integer i = null;
		System.out.println("Hi");
		System.out.println(" str : "+ i.toString() + " !");
		
		OvridingMethCheckedEx obj = new OvridingMethCheckedEx();
		try {
			obj.fun1();
		} catch (IOException e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Chap2test obj2 = new Chap2test();
//		try {
//			obj2.fun1();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		Chap2test obj3 = new OvridingMethCheckedEx();
		try {
			obj3.fun1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void fun1() throws IOException {
		System.out.println("Child");
	}

}

class Chap2test {
	
	Chap2test(){}
	Chap2test(int x) {
		//this();
		System.out.println("Yo yo");
	} 
	
	public void fun1() throws Exception {
		System.out.println("Parent");
	}
}
