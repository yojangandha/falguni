package com.aadityatiwari.java.scjp6.chap5;


enum COLOR {red, blue, green}

public class test1 {
	
	static int c;
	final static int b =2;
	static Integer intWrapper;
	
	
	
	public static void main(String[] args) {
		
		//System.out.println(intWrapper + c);
		
		test1();
		int x =2;
		int [] a = {1,2,3,4,5};
		for(int y:a){
		//int y =a[0];
		//for(y:a){  // compilation fails, y needs to be declared within the loop
			System.out.println(x);
		}
		testLabeled();
		
	}
	public static void testLabeled(){
		outer:
			//System.out.println("After Outer label");
			for(int i=0;i<5;i++)
			{
				for(int j=0;j<5;j++){
					System.out.println("i = "+i + "j = "+j);
					continue outer;
				}
				System.out.println("OUTSIDE OF INNER LOOP BUT AFTER CONTINUE: THIS Should not execute");
			}	
			System.out.println("BYE !!");
	}
	
	public static void test1()
	{
		COLOR c = COLOR.red;
		switch(c)
		{
			case blue : System.out.println("blue");
			case red: System.out.println("red");
			case green: System.out.println("green");
			default: System.out.println("default");
		}
		
		final int a;
		a =2;
		System.out.println("a : "+a + " b : "+b + " Static var c : "+c);
		byte g =2;
		switch((int)g)
		{
			default: System.out.println("Default");
			case 2: System.out.println("CASE : 2");
			case 12: System.out.println("CASE : 12");
			case 199: System.out.println("CASE : 127");
		}
	}

}
