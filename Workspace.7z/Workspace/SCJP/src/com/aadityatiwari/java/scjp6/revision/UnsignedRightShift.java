package com.aadityatiwari.java.scjp6.revision;

import java.util.Date;

public class UnsignedRightShift {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Date before = new Date();
        for (int j = 1 ;j < 300000 ; j++) {
                int a = 1 ;
                for (int i = 0 ;i< 10;i++){
                        a *=2;
                }
        }
        Date after = new Date();
        System.out.println("Multiplying "+(after.getTime()-before.getTime())+" milliseconds");
        before = new Date();
        for (int j = 1 ;j < 300000 ; j++) {
                int a = 1 ;
                for (int i = 0 ;i< 10;i++){
                        a = a << 1;
                }
        }
        after = new Date();
        System.out.println("Shifting "+(after.getTime()-before.getTime())+" milliseconds");
    

	}

}
