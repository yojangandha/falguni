package com.aadityatiwari.java.scjp6.chap6;

public class ClassA {
	int aX;
	static int aS;
	
	static {
		aS = 10;
		System.out.println("CLASS A :: STATIC BLOCK" + "STATIC var aS ="+aS);
	}
	
	{
		aX = 50;
		System.out.println("CLASS A :: INSTANCE BLOCK" + "INSTANCE var aX ="+aX);
	}
	
	public ClassA() {
		System.out.println("CLASS A :: CONSTRUCTOR METHOD");
	}

	public int getaX() {
		return aX;
	}

	public void setaX(int aX) {
		this.aX = aX;
	}
	
	

}
