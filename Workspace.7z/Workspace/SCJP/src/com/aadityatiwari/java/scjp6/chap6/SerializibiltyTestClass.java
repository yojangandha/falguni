package com.aadityatiwari.java.scjp6.chap6;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializibiltyTestClass {
	
	public static void main(String[] args) {
		
		ClassB obj = new ClassB(100,200);
		//ClassB obj2 = new ClassB(250,350);
		System.out.println("--------------------BEFORE SERIALIZATION-------------------------");
		System.out.println("obj.aX = "+ obj.aX +" obj.bX = "+ obj.bX);
		
		try {
		FileOutputStream fs = new FileOutputStream("testSer.ser");		
		ObjectOutputStream os = new ObjectOutputStream(fs);
		os.writeObject(obj);
		os.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			FileInputStream fis = new FileInputStream("testSer.ser");		
			ObjectInputStream ois = new ObjectInputStream(fis);
			obj = (ClassB)ois.readObject();
			ois.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		System.out.println("--------------------AFTER SERIALIZATION-------------------------");
		System.out.println("obj.aX = "+ obj.aX +" obj.bX = "+ obj.bX);
	}

}
