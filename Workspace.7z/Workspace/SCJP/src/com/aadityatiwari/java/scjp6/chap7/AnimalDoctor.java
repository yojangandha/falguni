package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;

public class AnimalDoctor {

	public static void main(String[] args) {
		
		ArrayList<Animal> anml = new ArrayList<Animal>();
		//int AnimalDoctor =0;
		anml.add(new Dog());
		anml.add(new Cat());
		anml.add(new Animal());
		checkAnimal(anml);
		
		ArrayList<Dog> dogs = new ArrayList<Dog>();
		dogs.add(new Dog());
		dogs.add(new Dog());
		//dogs.add(new Animal());
		//dogs.add(new ());
		checkAnimal(dogs);

	}
	public static void checkAnimal(ArrayList<? extends Animal> animals)
	{
		//animals.add(new Horse());
		for(Animal a : animals)
			a.checkUp();
	}

}

class Animal {
	public void checkUp()
	{
		System.out.println("Inside ANIMAL ---");
	}
} 

class Dog extends Animal {
	
	public void checkUp()
	{
		System.out.println("Dog CheckUp");
	}
}
class Cat extends Animal {
	
	public void checkUp()
	{
		System.out.println("Cat CheckUp");
	}
}
class Horse extends Animal {
	
	public void checkUp()
	{
		System.out.println("Horse CheckUp");
	}
}
