package com.aadityatiwari.java.scjp6.practiceExam1;

public class Q44 {
	private int x =2;
	
	private void method1()
	{ System.out.println("Inside Private method of Q44"); }
	
	class TestClass44
	{	private int x =2;
		private void method1()
		{ System.out.println("Inside Private method of TestClass44"); }
	}
	
	public static void main(String[] args) {
		Q44 obj = new Q44();
		obj.method1();
		System.out.println("Private int accessed using obj.x = "+obj.x);
		
		TestClass44 obj2 = new Q44().new TestClass44();
		obj2.method1();
		System.out.println("Private int accessed using obj.x = "+obj2.x);
	}
}


