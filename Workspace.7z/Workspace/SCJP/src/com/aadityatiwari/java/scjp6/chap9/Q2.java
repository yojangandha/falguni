package com.aadityatiwari.java.scjp6.chap9;

public class Q2 extends Thread{

	public static void main(String[] args) {
		Q2 t = new Q2();
		Thread x = new Thread(t);
		x.start();
	}
	public void run()
	{
		for(int i=0;i<3;++i) {
			System.out.print(i + "..");
		}
	}
}
