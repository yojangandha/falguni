package com.aadityatiwari.java.scjp6.chap3;

public class IntLongWideningTest {

	public static void main(String[] args) {
		TestA ref = new TestB();
		ref.fun1(5, 2);
		ref.fun1(Integer.MAX_VALUE-1, 2);
	}

}

class TestA {
	final int x=1;
	{
		System.out.println(x);
		//x =1;
	}
	public void fun1(int a, int b) {
		System.out.println("int :"+ (a+b));
	}

	public void fun1(double a, double b){
		System.out.println("double :"+ (a+b));
	}

	public void fun1(long a, long b){
		System.out.println("long :"+ (a+b));
	}
}

class TestB extends TestA {
//	final int x=1;
//	{
//		System.out.println(x);
//		//x =1;
//	}
	public void fun1(long a, long b){
		System.out.println("long :"+ (a+b));
	}
	public void fun1(String a, String b){
		System.out.println("String :"+ (a+b).length());
	}
}
