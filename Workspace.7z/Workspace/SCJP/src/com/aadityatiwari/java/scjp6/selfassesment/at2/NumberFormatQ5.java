package com.aadityatiwari.java.scjp6.selfassesment.at2;

import java.text.NumberFormat;
import java.text.ParseException;

public class NumberFormatQ5 {

	public static void main(String[] args) throws Exception{
		String s = "123.45x34455";
		NumberFormat nf = NumberFormat.getInstance();
		//try {
			System.out.println(nf.parse(s));
		//} catch (ParseException e) {
		//	e.printStackTrace();
		//}
		
	}

}
