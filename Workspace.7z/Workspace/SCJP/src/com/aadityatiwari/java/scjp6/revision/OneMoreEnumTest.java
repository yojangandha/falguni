package com.aadityatiwari.java.scjp6.revision;

public class OneMoreEnumTest {

	public static void main(String[] args) {
		X x = new X();
		print(x);
		x.printArrayToIterateOver();
		X y = new X();
		x.printArrayToIterateOver();
		y.printArrayToIterateOver();
	}
	static void print(X a){
		System.out.println("PRINT Method");
		for(int b : a.getArrayToIterateOver())
			System.out.print(b + " ");
		System.out.println("\nprint(X a)\n");
	}

}

class X {
	static int[] x = new int[5];
	
	{
		for(int i=0; i<5;i++)
			x[i]++;
	}
	
	public int[] getArrayToIterateOver(){
		System.out.println("\nInside getArrayToIterateOver()\n");
		return x;
	}
	
	public void printArrayToIterateOver()
	{
		for(int y : x)
			System.out.print(y + " ");
		System.out.println("\nprintArrayToIterateOver()\n");
	}
}
