package com.aadityatiwari.java.scjp6.at1;

public class Q10 extends Concrete {
		
	Q10() { System.out.println("r "); }
	public static void main(String[] args) {
	new Q10();
	}
}
	class Concrete extends Sand {
	Concrete() { System.out.print("c "); }
	private Concrete(String s) { }
	}

	abstract class Sand {
	Sand() { System.out.print("s "); }
	}

