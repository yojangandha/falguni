package com.aadityatiwari.java.scjp6.chap3;

public class InstanceOf {

	public static void main(String[] args) {
		InstanceOf obj = new InstanceOf();
		//if(obj instanceof A) {}
		if(new B() instanceof A) {}

	}

}

class A {}
class B extends A {}
