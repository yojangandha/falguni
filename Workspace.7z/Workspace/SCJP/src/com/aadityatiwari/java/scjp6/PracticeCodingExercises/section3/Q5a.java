package com.aadityatiwari.java.scjp6.PracticeCodingExercises.section3;

public class Q5a {

	public static void main(String[] args) {
		Q5a obj= new Q5a();
		int x = 5;
		obj.boxNWiden(x);
		float y = (float)6.11;
		obj.widenNBox(y); // can't widen to double and box >> too much for compiler but can just widen for a match
		
	}
	
	void boxNWiden(Number n)
	{
		System.out.println("boxNWiden(Number n) : n.intValue() : "+n.intValue());
	}
	
	void widenNBox(Double l)
	{
		System.out.println("widenNBox(Double l) : l.floatValue() : "+l.floatValue());
	}
	
	void widenNBox(double l)
	{
		System.out.println("widenNBox(double l) : l: "+l);
	}
}
