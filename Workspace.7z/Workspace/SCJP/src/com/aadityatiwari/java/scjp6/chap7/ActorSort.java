package com.aadityatiwari.java.scjp6.chap7;

import java.util.Comparator;

public class ActorSort   implements Comparator<DVDInfoForComparator>{
	
	public int  compare(DVDInfoForComparator d1, DVDInfoForComparator d2)
	{
		return d1.getLeadActor().compareTo(d2.getLeadActor());
	}
}
