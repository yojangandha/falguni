package com.aadityatiwari.java.scjp6.chap3;

public class EqualsWrappertest {

	
	public static void main(String[] args) {
		Integer i1 = Integer.valueOf(1);
		Integer i2 = Integer.valueOf(1);
		
		Integer i3 = 2;
		Integer i4 = 2;
		
		Integer i5 = 2000;
		Integer i6 = 2000;
		
		System.out.println("i1 == i2 : "+(i1 == i2));
		System.out.println("i1 != i2 : "+(i1 != i2));
		System.out.println("(i1.equals(i2) : "+(i1.equals(i2))+"\n");
		
		System.out.println("i3 == i4 : "+(i3 == i4));
		System.out.println("i3 != i4 : "+(i3 != i4));
		System.out.println("(i3.equals(i3) : "+(i3.equals(i4))+"\n");
		
		System.out.println("i5 == i6 : "+(i5 == i6));
		System.out.println("i5 != i6 : "+(i5 != i6));
		System.out.println("(i5.equals(i6) : "+(i5.equals(i6))+"\n");
		
		System.out.println("(5.0 == 5) : "+(5.0 == 5));
		System.out.println("(500000.0 == 500000) : " + (500000.0 == 500000));
		System.out.println(" (5.0 == 5L) : " + (5.0 == 5L));
		System.out.println("(500000.0 == 500000L) : " + (500000.0 == 500000L));
		
		Integer i7 = 5000;
		Long i8 = 5000L;
		
		//System.out.println("i7 == i8 : "+(i7 == i8));
		//System.out.println("i7 != i8 : "+(i7 != i8));
		System.out.println("i7 : "+ i7 + " i8 : "+i8);
		System.out.println("(i7.equals(i8) : "+(i7.equals(i8))+"\n");
		System.out.println("i8 ==5000.0 : "+(i8 ==5000.0));
		
		float f1 = 2.3f;
		float f2[]={2.6f,2.3f};
		//System.out.println(f1==f2);
		System.out.println(f1==f2[0]);
		System.out.println(f1==f2[1]);
		
		
		
	}

}
