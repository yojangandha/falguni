package com.aadityatiwari.java.scjp6.chap6;

import java.io.InputStreamReader;

public class ConsoleTestQ11 {
	
	public static void main(String[] args) {
	
//		Console c = System.console();
//		if(c==null)
//			System.out.println("CONSOLE IS NULL\n");
//		String u = c.readLine("%s","Username:");
//		System.out.println("Hello "+u);
//		
//		char[] pw;
//		if(c!=null && (pw = c.readPassword("password: "))!=null)
//			System.out.println("WELCOME");
		System.out.print("Username : ");
		InputStreamReader is = new InputStreamReader(System.in);
		//String test = System.in.read();
		String username = is.toString();
		System.out.println("Hello : "+username);
		
		InputStreamReader is2 = new InputStreamReader(System.in);
		String password = is2.toString();
		System.out.println("Password : "+password);
		
		
	}

}
