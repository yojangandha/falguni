package com.aadityatiwari.java.scjp6.selfassesment.at2;

public class GenericTypesQ12 {

	public static void main(String[] args) {
		
	}

}

class A {}
class B extends A {}
class C extends B {}

class Carpet <V extends B>
{
	public <X extends V> Carpet<? extends V> method (Carpet <? super X> e)
	{
		return new Carpet<X>();
	}
}
