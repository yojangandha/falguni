package com.aadityatiwari.java.scjp6.chap1;

public class StaticMetInIntefaceWhyNotA {
	
	public static void foo()
	
	{
		System.out.println("A");
	}
	public void printfoo()
	{
		foo();
	}
	

}
