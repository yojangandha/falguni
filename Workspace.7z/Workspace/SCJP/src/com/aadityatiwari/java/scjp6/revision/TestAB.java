package com.aadityatiwari.java.scjp6.revision;

public class TestAB {

	public static void main(String[] args) {
		ZZ obj = new ZZ();
		Y obj2 = new Y();

	}

}

class ZZ {
	Y y;
	
	//ZZ()
}

class Y {
	ZZ x;
}
