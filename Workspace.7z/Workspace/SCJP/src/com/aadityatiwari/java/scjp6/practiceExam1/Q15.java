package com.aadityatiwari.java.scjp6.practiceExam1;

import java.util.List;
import java.util.Vector;

interface test
{
	String dummy = "hands";
	void method1();
}

public class Q15 implements test {
	static String dummy = "legs";
	public void method1() {;;;;}	
	
	String s;
	int n;
	
	String getS()
	{
		return s;
	}
	void setS(String str)
	{
		if(str==null) throw new NullPointerException();
		s=str;
	}
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	
	
	public static void main(String[] args) {
		List<Integer> i = new Vector<Integer>();
		i.add(1);
		i.add(2);
		System.out.println(dummy);
		System.out.println(test.dummy);
	}

}
