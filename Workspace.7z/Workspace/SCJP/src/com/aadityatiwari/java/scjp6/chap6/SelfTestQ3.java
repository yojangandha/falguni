package com.aadityatiwari.java.scjp6.chap6;

public class SelfTestQ3 {

	
	public static void main(String[] args) {
		String s = "-";
		Integer x = 343;
		Long L343 = 343L;
		
		testOpearators();
		
		if(x.equals(L343))
			s+=".e1 ";
		if(x.equals(343))
			s+=".e2 ";
		Short s1 = (short) ( (new Short((short)343))  / (new Short((short)49)) );
		if(s1 == 7)
			s+= "=s ";
		if (s1< new Integer(7+1))
			s+= "fly ";
		
		System.out.println("\n\nIn Main :: String s = "+s);
		
	}
	
	public static void testOpearators()
	{
		System.out.println("------------------BEGIN----------------");
			Integer i1 = 500;
			Integer i2 = 500;
			int i3 = 500;
			Integer i4 = new Integer(500);
		System.out.println("----------------------   ==   -----------------------");
		System.out.println("i1 == i2 ::"+ (i1 == i2) + " i1!=i2 :: "+(i1!=i2)+"");
		System.out.println("i1 == i3 ::"+ (i1 == i3) + " i1!=i3 :: "+(i1!=i3)+"");
		System.out.println("i1 == i4 ::"+ (i1 == i4) + " i1!=i4 :: "+(i1!=i4)+"");
		System.out.println("i4 == i3 ::"+ (i4 == i3) + " i4!=i3 :: "+(i4!=i3)+"");
		System.out.println("----------------------   equals()  -----------------------");
		System.out.println("i1.equals(i2) ::"+ (i1.equals(i2)));
		System.out.println("i1.equals(i3) ::"+ (i1.equals(i3)));
		System.out.println("i1.equals(i4) ::"+ (i1.equals(i4)));
		System.out.println("i4.equals(i3) ::"+ (i4.equals(i3)));

		System.out.println("------------------End----------------");
	}

}
