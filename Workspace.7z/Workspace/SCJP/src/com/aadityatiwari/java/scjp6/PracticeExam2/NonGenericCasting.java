package com.aadityatiwari.java.scjp6.PracticeExam2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Snack{
	static List<String> s1 = new ArrayList<String>();
}

public class NonGenericCasting extends Snack{

	public static void main(String[] args) {
		List c1 = new ArrayList();
		s1.add("1");s1.add("2");
		c1.add("3");c1.add("4");
		getStuff(s1,c1);
		
		System.out.println("Test 2 : HashTable null keys/values insertion");
		Map<String, String> h = new HashMap<String, String>();
		String[] k = {"1","2","3",null};
		String[] v = {"a","b",null,"d"};
		
		for(int i=0;i<4;i++){
			h.put(k[i], v[i]);
			System.out.print(h.get(k[i])+ " ");
		}
		System.out.println("\n\n"+h.size() + "\t\t " + h.values() );
	}
	static void getStuff(List<String> a1, List a2){
		for(String s1 : a1) System.out.print(s1 + " ");
		for(Object s2 : a2) System.out.print(s2 + " ");
	}

}
