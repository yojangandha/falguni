package com.aadityatiwari.java.scjp6.PracticeExam2;

import java.util.Properties;

/** Question #38 */
abstract class Nameable {
	String name;
}
class Animal extends Nameable {
	Animal(String n) {name =n;}
	String getName() {return name;}
}


public class Buddies extends Animal{
	Buddies(String s) {super(s);}
	public static void main(String[] args) {
		Animal b1 = new Animal("Kara");
		//Buddies b2 = new Buddies();
		Buddies b2 = new Buddies("Charis");
		System.out.println(b1.getName() + " "+ b2.getName());
		Properties p = System.getProperties();
		System.out.println(p.getProperty("whatever"));
	}

}
