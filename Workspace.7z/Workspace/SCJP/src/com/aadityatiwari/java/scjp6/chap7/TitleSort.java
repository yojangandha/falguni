package com.aadityatiwari.java.scjp6.chap7;

import java.util.Comparator;

public class TitleSort  implements Comparator<DVDInfoForComparator>{
	
	public int  compare(DVDInfoForComparator d1, DVDInfoForComparator d2)
	{
		return d1.getTitle().compareTo(d2.getTitle());
	}
}
