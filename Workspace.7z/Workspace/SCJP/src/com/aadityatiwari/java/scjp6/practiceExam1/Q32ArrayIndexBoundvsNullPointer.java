package com.aadityatiwari.java.scjp6.practiceExam1;

public class Q32ArrayIndexBoundvsNullPointer {
	
	
	
	public static void main(String[] args) throws ArrayIndexOutOfBoundsException {
		
		if(args.length>0)
			System.out.println("Shouldn't be here");
		if(!args[0].equals("a"))
			System.out.println("Should throw (ArrayIndexOutOfBound or NullPointer) Exception rather than printing this");
	}

}
