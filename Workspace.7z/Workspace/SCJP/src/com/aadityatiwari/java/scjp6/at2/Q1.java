package com.aadityatiwari.java.scjp6.at2;

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import static java.lang.Short.*;
//import static java.lang.Long.*;

public class Q1 implements Comparator<Q1>{
	int dishSize;
	
	public Q1(int x)
	{
		this.dishSize = x;
	}

	@Override
	public int compare(Q1 o1, Q1 o2) {
		
		return (o2.dishSize-o1.dishSize);
	}
	
	public static void main(String[] args) {
		Q1[] va = {new Q1(40),new Q1(200),new Q1(60),};
		System.out.print("Before Sorting : ");
		for(int i=0;i<va.length;i++)
			System.out.print(va[i].dishSize+" ");
		Arrays.sort(va,va[0]);
		System.out.print("\nAfter Sorting: ");
		for(int i=0;i<va.length;i++)
			System.out.print(va[i].dishSize+" ");
		int index = Arrays.binarySearch(va, new Q1(40), va[0]);
		System.out.print("\n"+index + " ");
		index = Arrays.binarySearch(va, new Q1(80), va[0]);
		System.out.print(index);	
		File f = new File("");
		//File.
		System.out.println(MAX_VALUE);
	}
	
	

}
