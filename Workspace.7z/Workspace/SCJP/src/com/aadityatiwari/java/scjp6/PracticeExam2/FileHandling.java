package com.aadityatiwari.java.scjp6.PracticeExam2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandling {

	public static void main(String[] args) {
		File f = new File("NewFile.txt");
		try {
			FileWriter fw = new FileWriter(f);
			fw.write("Line 2");
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Test 2 : throwing wider exception");
		A a = new A();
		//a.fun1();
		B b = new B();
		b.fun1();
	}
}

class A {
	void fun1() throws IOException {
		System.out.println("A : fun1");
	}
}
class B extends A {
	protected void fun1() {
		System.out.println("B : fun1");
	}
}
class C extends A {
	void fun1() throws FileNotFoundException {
		System.out.println("C : fun1");
	}
}
class D extends A {
//	void fun1() throws Exception {
//		System.out.println("D : fun1");
//	}
}
