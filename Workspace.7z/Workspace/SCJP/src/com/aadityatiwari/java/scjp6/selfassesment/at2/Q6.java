package com.aadityatiwari.java.scjp6.selfassesment.at2;

public class Q6 extends ParentQ6 implements Runnable {
	public static long id;
	static 
	{
		System.out.println("Q6 : STATIC BLOCK");
	}
	
	Q6()
	{
		//super(s);
		System.out.println("Q6 : CONSTRUCTOR METHOD ");
	}
	
	{
		System.out.println("Q6 : INSTANCE BLOCK");
	}
	
	public static void main(String[] args) {
		
		Q6 obj = new Q6();
		Thread t = new Thread(obj);
		System.out.println("t ID = "+ t.getId());
		System.out.println("main ID = "+ Thread.currentThread().getId());
		id = t.getId();
		t.start();
		
		//Thread t2 = new Thread(obj);
		//System.out.println("t2 ID = "+ t2.getId());
		//System.out.println("main ID = "+ Thread.currentThread().getId());
		//t2.start();
	}
	
	public void run()
	{
		System.out.println("Inside run() method ");
		System.out.println("run() Thread ID = "+ Thread.currentThread().getId());
		if(Thread.currentThread().getId()==id)
			{
				new Thread(new Q6()).start();
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		System.out.println("This should get printed for both the threads");
		throw new Error();
	}

}

class ParentQ6
{
	String s ="s";
	
	static 
	{
		System.out.println("ParentQ6 : STATIC BLOCK");
	}
	
	ParentQ6()
	{
		System.out.println("ParentQ6 : CONSTRUCTOR METHOD ");
	}
	
	{
		System.out.println("ParentQ6 : INSTANCE BLOCK");
	}
}
