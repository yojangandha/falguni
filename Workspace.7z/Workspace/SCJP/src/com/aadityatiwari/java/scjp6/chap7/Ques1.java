package com.aadityatiwari.java.scjp6.chap7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Ques1 {
	
	public static void main(String[] args) {
		//ques1();
		ques2();
		
		Collections.sort(new ArrayList());
		//TreeSet<E>
}
	
	public static void ques6()
	{
		
	}
	
	public static void ques1 () {
		List<List<Integer>> table = new ArrayList<List<Integer>>();
		for (int i = 1; i <= 10; i++) {
		List<Integer> row = new ArrayList<Integer>();
		for (int j = 1; j <= 10; j++)
		row.add(i * j);
		table.add(row);
		}
		for (List<Integer> row : table)
			System.out.println(row);
	}

	public static void ques2 ()
	{
		Set set = new TreeSet();
		set.add("2");
		set.add(3);
		set.add("1");
		Iterator it = set.iterator();
		while (it.hasNext())
		System.out.print(it.next() + "\t");
	}
}
