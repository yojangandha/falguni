package com.aadityatiwari.java.scjp6.chap7;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueTest {
	
	public static void main(String[] args) {
		String[] sa = {">ff<" , "> f<" , ">f <" , ">FF<"};
		PriorityQueue<String> pq = new PriorityQueue<String>();
		for (String s : sa)
		{
			pq.offer(s);
		}
		Iterator<String> it = pq.iterator();
		while(it.hasNext())
			System.out.print(it.next() +"\t");
		System.out.println();
		for (String s : sa)
			System.out.print(pq.poll() + "\t");
		testPQueue();
	}
	
	public static void testPQueue()
	{
		System.out.println("\n\n------------------------INSIDE PQ Method-----------------------\n\n");
		Integer[] ia = {1,5,2,4,9,7};
		PriorityQueue<Integer> pqi = new PriorityQueue<Integer>();
		for(Integer obj : ia)
			pqi.offer(obj);
		
		Iterator<Integer> it = pqi.iterator();
		
		while(it.hasNext())
			System.out.print(it.next() +"\t");
		System.out.println();
		for(Integer obj : ia)
			System.out.print(pqi.poll()+ "\t");
		
		System.out.println("\n\n------------------------END Of PQ Method-----------------------\n\n");
		
		int i =2;
		int j =2;
		int k = ++j + ++j * ++j;
		System.out.println("k = "+k + "\t j = "+j);
		System.out.println("i++ + (i++ + i++)   ::  " + (i++ + (i++ + i++)));
	}

}
