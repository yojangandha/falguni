package com.aadityatiwari.java.scjp6.chap6;

public class TestStringToString {

	
	public static void main(String[] args) {

		String x = "Very Funny";
		System.out.println(x.toString());
	}

}
