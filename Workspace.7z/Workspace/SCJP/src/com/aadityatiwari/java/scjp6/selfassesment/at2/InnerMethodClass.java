package com.aadityatiwari.java.scjp6.selfassesment.at2;

public class InnerMethodClass {
	private int y = 8;
	public static void main(String[] args) {		
		
		try {
			throw new Exception();
		} catch (Exception e) {
			System.out.println("Inside Catch");
			new InnerMethodClass().go();
		}
		finally
		{
			System.out.println("Finally !");
		}
	}
	
	void go()
	{
		final int x =7;
		//ABC obj = new ABC();
		class ABC 
		{
			void doIt()
			{
				System.out.println("y+x = "+(y+x));
			}
		}
		new ABC().doIt();
	}

}
