package com.aadityatiwari.java.scjp6.regularExpressions;

public class ClassA {
	static String test ="This is a sample string which contains all the characters just like " +
			"a quick brown fox jumps over the lazy dog";
	static String test2 = "c d";
	static String test3 = "ab.1 cd";
	static String test4 = ".a.b.c.d.e1e2e3.ffff.g...h.ii.j..k1k2...l.";
	
	public static void main(String[] args) {
		
		System.out.print(test4.matches("\\..")+ ": "); String d[] = test4.split("\\..");
		for(String s : d)
			System.out.print(s+",");
		System.out.println("\nd.length : " + d.length);
		
		System.out.print(test3.matches("\\.")+ ": "); String c[] = test3.split("\\.");
		for(String s : c)
			System.out.print(s+",");
		System.out.println("\nc.length : "+c.length);
		
//		System.out.println("test.length() : "+test.length());
//		
//		System.out.print(test.matches("\\w")+ ": "); String a[] = test.split("\\w");
//		for(String s : a)	
//			System.out.print(s+ ","); 
//		System.out.println("\na.length : "+a.length);
//		
//		System.out.print(test2.matches("\\s")+ ": "); String b[] = test2.split("\\s");
//		for(String s : b)	
//			System.out.print(s+ ",");
//		System.out.println("\nb.length : "+b.length);
//		

	}
}
