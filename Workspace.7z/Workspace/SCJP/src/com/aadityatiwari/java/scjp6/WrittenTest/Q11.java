package com.aadityatiwari.java.scjp6.WrittenTest;

import java.util.Comparator;

public class Q11 {
	String str;
	
	public static void main(String[] args) {
		Q11 obj = new Q11();
		//System.out.println(obj.str.toString());
		String str2 = null;
		System.out.println(str2);		
		//Vector obj = new Vector();
		
		System.out.println("Tests 2 begins");
		B objB = new B();
		objB.displayX();
		System.out.println("objB.x : "+objB.x);
		
		System.out.println("Test 3 begins");
		int x=5;
		assert(true) : "1";
		assert(x>6) : "x is less than 6";
		assert(false);
		assert(true) : "3";
		assert(false): "4";
	}

}

class A {
	protected static int x =5;
	 void method1()
	{
		System.out.println("A");
	}
}
class B<T> extends A implements Comparator<T>{
	protected void method1()
	{
		System.out.println("B");
	}
	
	public void displayX(){
		System.out.println(B.x+" "+A.x + " "+x);
	}

	@Override
	public int compare(T o1, T o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
