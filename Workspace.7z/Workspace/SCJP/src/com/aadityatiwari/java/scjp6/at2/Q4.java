package com.aadityatiwari.java.scjp6.at2;

public class Q4 {
	static Weather w ;
	
	public static void main(String[] args) {
		
		System.out.println("MAIN: w.RAINY.count : "+w.RAINY.count);
		//System.out.println("MAIN: w.sunny.count : "+w.sunny.count);
		//System.out.println("MAIN: w : "+w);
		if(true)
			if(false)
				if(false)
					System.out.println("All true");
				else System.out.println("3 - false");
			else System.out.println("2 - false");
		else System.out.println("1 - false");

	}
}
enum Weather
{	RAINY, sunny, hot;
	int count=0;
	
	static
	{
		System.out.println("In static RAINY.count : "+RAINY.count);
		RAINY.count +=5;
	}
	
	Weather()
	{
		System.out.println("Constructor: " +(++count));
	}
	
	
}
