package com.aadityatiwari.java.scjp6.chap9;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;

public class ReaderThread extends Thread {
	Calculator calc;
	
	public ReaderThread(Calculator calc)
	{
		this.calc = calc;
	}
	
	public static void main(String[] args) {
		Calculator c = new Calculator();
		ReaderThread rt1 = new ReaderThread(c);
		ReaderThread rt2 = new ReaderThread(c);
		ReaderThread rt3 = new ReaderThread(c);
		rt1.setName("rt1");
		rt2.setName("rt2");
		rt3.setName("rt3");
		rt1.start();
		rt2.start();
		rt3.start();		
		c.start();
		c.addJob();
	}
//	public void run()
//	{
//		synchronized (calc) {
//			while(calc.getList().isEmpty()){
//				try {
//					System.out.println(Thread.currentThread().getName() + " :: Waiting for calculation ...");
//					calc.wait();
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//			}
//			System.out.println("For Thread "+Thread.currentThread().getName() + ", Total : "+calc.total);
//		}
//	}

}

class Calculator extends Thread
{	int total;
	List<String> list = new ArrayList<String>();

	public List<String> getList() {
		return list;
	}
	
//	public void run()
//	{
//		synchronized (this) {
//			for(int i=0;i<100;i++)
//				total+=i;
//			
//			//notifyAll();
//			//notify();
//			System.out.println("CALCULATOR LOCK RELEASED");
//		}
//	}
	public void addJob()
	{
		synchronized (list) {
			list.add("job");
			list.notify();
		}
	}
	
}
