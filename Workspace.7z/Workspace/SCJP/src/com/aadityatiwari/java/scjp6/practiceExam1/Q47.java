package com.aadityatiwari.java.scjp6.practiceExam1;

class Dog 
{	void makeNoise(){ 
		System.out.println("bark ");
	}
	static void play(){ 
		System.out.println("catching ");
	}
}

public class Q47 extends Dog{
	
	void makeNoise(){ 
		System.out.println("howl");
	}	
	public static void main(String[] args) {
		Q47 obj = new Q47();
		obj.go();
	}
	void go(){	
		super.play();
		makeNoise();
		super.makeNoise();
	}
}
