package com.aadityatiwari.java.scjp6.chap4;

public class Ques1 {
	public static void main(String[] args) {
	Integer i =42;
	String s = (i<40)  ? "life" : "noLife" ;
	System.out.println(s);
}
}
