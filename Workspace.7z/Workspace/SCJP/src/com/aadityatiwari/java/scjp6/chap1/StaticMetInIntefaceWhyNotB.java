package com.aadityatiwari.java.scjp6.chap1;

public class StaticMetInIntefaceWhyNotB extends StaticMetInIntefaceWhyNotA {

	public static void foo()	
	{
		System.out.println("B");
	}
	public static void main(String[] args) {
		
		StaticMetInIntefaceWhyNotB obj = new StaticMetInIntefaceWhyNotB();
		StaticMetInIntefaceWhyNotA obj2 = new StaticMetInIntefaceWhyNotA();
		obj.printfoo();
		obj2.printfoo();
	}
}
