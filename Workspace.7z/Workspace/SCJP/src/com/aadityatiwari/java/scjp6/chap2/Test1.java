/**
 * 
 */
package com.aadityatiwari.java.scjp6.chap2;

/**
 * @author atiwari32
 *
 */
public class Test1 {
	
	public void eat(){
		System.out.println("TEST1 : eat() ");
	}

}
