package com.aadityatiwari.java.scjp6.chap9;

public class WaitNotifyThread {

	
	public static void main(String[] args) {
		ThreadX t = new ThreadX();
		t.start();
		
		//synchronized(t)
		//{
			System.out.println("Inside main (synchronized), Waiting for ThreadX to complete");
			try {
				//t.wait();
				t.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("main thread notified, lock released, Final sum : "+t.count);
		//}

	}

}

class ThreadX extends Thread
{	int count=0;
	public void run()
	{
		synchronized(this)
		{
			for(int i=0;i<100;i++)
				count+=i;
			
			//notify();
		}
		
	}
}
