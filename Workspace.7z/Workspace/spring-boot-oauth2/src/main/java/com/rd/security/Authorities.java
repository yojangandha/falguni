package com.rd.security;

public enum Authorities {

    ROLE_ANONYMOUS,
    ROLE_USER,
    ROLE_ADMIN

}
