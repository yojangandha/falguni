package com.c4.min.microservices.spots;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * A RESTFul controller for accessing spots.
 * 
 */
@RestController
public class SpotsController {

	protected Logger logger = Logger.getLogger(SpotsController.class.getName());
	protected SpotRepository spotRepository;

	/**
	 * Create an instance plugging in the respository of spots.
	 * 
	 * @param spotRepository
	 *            An spot repository implementation.
	 */
	@Autowired
	public SpotsController(SpotRepository spotRepository) {
		this.spotRepository = spotRepository;

		logger.info("SpotRepository says system has " + spotRepository.countSpots() + " spots");
	}

	
	@RequestMapping("/spots/")
	public List<Spot> getAllSpots() {
	
		logger.info("========SpotsController - spot-service getAll invoked: " + spotRepository.getClass().getName());
		List<Spot> spots = spotRepository.findAll();

		return spots;

	}
	@RequestMapping(value = "/addSpot", 
            method = RequestMethod.POST,
            headers = {"Content-type=application/json"})
	public Spot save(@RequestBody Spot paramSpot) {
	
		logger.info("========SpotsController - spot-service save invoked: " + spotRepository.getClass().getName());
		Spot spot = spotRepository.save(paramSpot);

		return spot;

	}
	
	@RequestMapping(value = "/delete")
	public void delete(Long paramId) {
	
		logger.info("========SpotsController - spot-service delete invoked: " + spotRepository.getClass().getName());
		spotRepository.delete(paramId);

	}
}
