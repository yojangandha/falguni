package com.c4.min.microservices.spots;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 * Repository for Spot data implemented using Spring Data JPA.
 * 
 * @author Arun
 */
public interface SpotRepository extends Repository<Spot, Long> {
	
	/**
	 * Fetch all Spots
	 * @return all Spots
	 */
	public List<Spot> findAll();

	/**
	 * Fetch the number of Spots known to the system.
	 * 
	 * @return The number of spots.
	 */
	@Query("SELECT count(*) from Spot")
	public int countSpots();
	
	
	/**
	 * Creates a new spot in the system.
	 * 
	 * @return The persisted Spot.
	 */
	
	public Spot save(Spot paramSpot);
	
	/**
	 * Deletes a new spot in the system.
	 * 
	 */
	
	public void delete(Long paramId);
	
}
