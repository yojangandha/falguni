package com.javapapers.java.security;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class AESFileDecryption {
	public static void main(String[] args) throws Exception {

		String password = "40+H624Z(9dDVUQV142dp"
				+ "4FCeD<cEcFu9x&"
				+ "NnMZ2sA6vTHx8AF0C9"
				+ "_9/OC6E0qDN7C03"
				+ "C&t1bzw4'5M2^e4D3B"
				+ "1ZR|eEv6*oA;Fl5EWV"
				+ "hK42d263CsrLx"
				+ "0c10p|0bClN"
				+ "6GJx8%JJ7$"
				+ "7bYBR77BF"
				+ "B6meF32g1b8e"
				+ "A8]=e9s'r3"
				+ "7A`2MfA'42"
				+ "4665C2E75y";

		// reading the salt
		// user should have secure mechanism to transfer the
		// salt, iv and password to the recipient
		FileInputStream saltFis = new FileInputStream("D://khatam/salt.enc");
		byte[] salt = new byte[8];
		saltFis.read(salt);
		saltFis.close();

		// reading the iv
		FileInputStream ivFis = new FileInputStream("D://khatam/iv.enc");
		byte[] iv = new byte[16];
		ivFis.read(iv);
		ivFis.close();

		SecretKeyFactory factory = SecretKeyFactory
				.getInstance("PBKDF2WithHmacSHA1");
		KeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, 65536,
				256);
		SecretKey tmp = factory.generateSecret(keySpec);
		SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");

		// file decryption
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(iv));
		FileInputStream fis = new FileInputStream("D://khatam/encryptedfile.des");
		FileOutputStream fos = new FileOutputStream("D://khatam/Important2.docx");
		byte[] in = new byte[64];
		int read;
		while ((read = fis.read(in)) != -1) {
			byte[] output = cipher.update(in, 0, read);
			if (output != null)
				fos.write(output);
		}

		byte[] output = cipher.doFinal();
		if (output != null)
			fos.write(output);
		fis.close();
		fos.flush();
		fos.close();
		System.out.println("File Decrypted.");
	}
}